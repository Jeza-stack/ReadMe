import { Menu, HelpCircle, CheckCircle, ArrowRight, Flag, Brain, BarChart2, User, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

export default function Assessment() {
  const navigate = useNavigate();
  const [selectedOption, setSelectedOption] = useState<string | null>('B');

  return (
    <div className="bg-surface text-on-surface min-h-screen flex flex-col">
      {/* TopAppBar */}
      <header className="fixed top-0 w-full z-50 bg-surface/80 dark:bg-slate-950/80 backdrop-blur-md shadow-sm shadow-on-background/5">
        <div className="flex items-center justify-between px-6 py-4 max-w-full mx-auto">
          <div className="flex items-center gap-4">
            <button className="text-primary dark:text-blue-400 active:scale-95 duration-200">
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="font-sans tracking-tight font-bold text-lg text-on-background dark:text-slate-100">IQ Global Standard</h1>
          </div>
          <div className="flex items-center gap-6">
            <div className="hidden md:flex gap-8">
              <span className="text-primary font-bold cursor-pointer">Assessments</span>
              <span className="text-on-surface-variant dark:text-slate-400 hover:bg-surface-container-low transition-colors cursor-pointer px-2 rounded-lg">Insights</span>
              <span className="text-on-surface-variant dark:text-slate-400 hover:bg-surface-container-low transition-colors cursor-pointer px-2 rounded-lg">Profile</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-primary-container flex items-center justify-center text-[10px] text-white font-bold">JD</div>
          </div>
        </div>
      </header>

      <main className="flex-grow pt-24 pb-32 px-6 max-w-5xl mx-auto w-full">
        {/* Subtle Progress Section */}
        <div className="mb-12">
          <div className="flex justify-between items-end mb-4">
            <div>
              <span className="text-on-surface-variant text-sm font-medium tracking-wide">LOGICAL REASONING</span>
              <h2 className="text-3xl font-extrabold text-on-surface tracking-tight mt-1">Matrix Pattern 14 of 40</h2>
            </div>
            <div className="text-right">
              <span className="text-primary font-bold text-lg">08:42</span>
              <p className="text-on-surface-variant text-xs uppercase tracking-widest">Time Remaining</p>
            </div>
          </div>
          {/* Progress Gauge */}
          <div className="h-2 w-full bg-surface-container-highest rounded-full overflow-hidden">
            <div className="h-full bg-secondary w-[35%] rounded-full"></div>
          </div>
        </div>

        {/* Testing Environment */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Question Canvas (Asymmetric Layout) */}
          <div className="lg:col-span-7">
            <div className="bg-surface-container-lowest p-8 md:p-12 rounded-[2rem] shadow-[0_24px_48px_-12px_rgba(7,30,39,0.06)] relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-surface-container-low rounded-bl-[4rem] -mr-8 -mt-8 transition-transform group-hover:scale-110 duration-700"></div>
              <div className="relative z-10">
                <p className="text-on-surface-variant mb-10 leading-relaxed text-lg max-w-md">
                  Analyze the sequential transformation of the geometric elements. Identify the missing component that logically completes the 3x3 matrix.
                </p>

                {/* The Matrix reasoning visual */}
                <div className="grid grid-cols-3 gap-6 bg-surface-container-low p-6 rounded-2xl">
                  {/* Matrix Cells */}
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDhwWiJMLjwPjxq4IAYamZgwlMoilf-R2itnWwNkEmrWkhAm5dg0mLgrrTyygy6FPFToUJjqYmk9MvhOsg7lR3T_bjkEETe2ztd3i2YqQ-6leeeO4TeEv6eCqv76EbPsEzoc9i9Nv1RlprE2vd_XjhVwxUrg5HnZFqKacHjPcLPxbNK9kBGAJZ0BWYIKIO0mnoYtlB2g-MPAosRZ8QJCY8JZqoeJqFjMlh-xVFQc333ufxIaQdXiVkLnp1WLIYuOQD-89Yr0OtKjdc" />
                  </div>
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD7YADkTxdS_-iZLol_XHHYGjisFFRFib5B717TlsgC7frkqWeQ48rpzZvbmZlexRMAiwPJRkuqmq6UkeL2uRtrNTnapJCtATxsc_cJO1n0GY-CE2CtKv1PGiOGxEMJ_Un4KHgAG9JWQANbrVL47_J2K24L5-q-lPpJIcknG_98ofrXW3D7LPGG1lT-Z3loVslL0kyKj9dMjTBH-GAUgVKskTfc7JxYXMFAe7MVUaPxT7AzuavshiuTosGBhkfgK0FNqwcbQ_VsYNs" />
                  </div>
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBBdrrQuwMLSpjDcNod6f5umhAnpnrka-J48LzS-bsALq2prhyE3URBDoLAY4qmvWIdRmjhKqAn-DBi4PLyKW7vZtTiPIuCv2bpcPlqqEH0q7uOdee9JuK9ZI0b58GTYR4oM9iqe1mpTTlfh7S1CP4R-28Fz6Qv3RhY11EP9jnwqiWu1YKKyaUtKj98Ol28Q--qN-VeqM9JHKZYKy8LlVOOp04T41vrTB3lAjsvijUmJgyOpqD5Eo1zl7k1AltyvaAnwqnoUO1sBpI" />
                  </div>
                  
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCsVNtMEz60MOkaE008LrBoEOD4Cm6unJr5ZxkACzPymRHNWFHhmJhzBdHVd0P8slIMrLuLtJIHUB9sNX6lZY-GS-8Qly8XS6m4heBeBre14vcuZ_BS5SmeZSZJsf6gY9SZVuhYSZfjmnTpSIpJGjgS0dek6LfeDJ3oke3-UcOZTBwX3LBvWRAHMJ6A_7jB0k2ENMUJfIrTqNXKES9HtJRkZCuqEiM-inlSbg8yt8YMrlncncnclOzHgSC6kxKKDHVuEOQVNO4h5Kw" />
                  </div>
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAvkXdH4V7SJQncHYDNkJF1pb7i2ip29aLDuKGJZn6FaPw1RLBPD-sNOgs7cviGT3xsvtGBrEJEn8N3PEzLzBJYbjvjSfbv2iUc6BuL7bq7T9jN5RUJ_aTvTziNMXME3FtN2FqgSda65ofQS5Gdyb33g7n8TN7q9_gDn8NtuAM6FkWb0-ZgxYSUZ6Yp36uCWUTTnRnJ7KlKyHFVYnKqCa08PA44iugeCx_dLI_Yep2si4H-cw0xtG2JmhcojU1HLlppT7KLAyXu7ZU" />
                  </div>
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBJtW7pQqd3U1a_s13c5XbdLG0mKVuzdiR1c461rbQsmb5SUQT0YSO1GQqm-_DPobzG96yXN75bhYtRrGM6oU-QNVweXO5gBS0UkgV-hOtlcn91-GmSZXFZWIrpRSD_n81A_EvGOQcAPFDC7EHsT4eLN6BCGDga8HNMg50zXZqo1h4ibsCU5ctg6xQq2pOIClWNBKpwINyMPRgU5kBUp03jfV7Gt7ZVeIx6DvDp0J_Nr_k4lKpovlRkqkrpYG02BYORoUQgoXzkTfM" />
                  </div>
                  
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBlEM-LR5qpDENRXn-7fAV_U-EISloZPpFjupNMx2A-UUNmVAyPZa6fw5KY8ZDsmeNHIryibiT1SE9l7kNKtHNXF9ysGk5ccw0XPaMbf8O-iEKzeBNg_Pe6xcfopxOMKt88RBSuohsy23rQVzUIkrx0AV1Pb4QV51XBLtTvJCGFUR91lbOWpWVs66gVlfCMsqUR8rlYoeOMShOeR_8VaSAhqk6Qzioa5rL8XvJONnUWj4TrfJGDO5bXdXueAXl4WiP15YgvKjpWE1g" />
                  </div>
                  <div className="aspect-square bg-white rounded-xl flex items-center justify-center shadow-sm">
                    <img className="w-16 h-16 opacity-80" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB5ff5avl5T91gAHoPmd-f10_Iv-5D2NcB3wpXEbE_jPbmT3PRvpftdHv-_UWKlkhZViRN0eeiYq6M2Vm_w1vC5kTsatamyxyXFrV4xKY7iqG72J4nBVP1I-y10zRb3A-97ik87xxtkjdlODmYOv5NeSDKJOJ1X6hd0wBtONWcEM-0RGmQ2GRJqbKjQL3x4mhV0HxEnzjDfSj8r5N2imHGmNqbEu0wSDajguzZxVPRqp2v03Mft6nMXYJBpEEhySGHIIZIe96UIm5A" />
                  </div>
                  
                  {/* Target Cell */}
                  <div className="aspect-square bg-surface-container-highest/50 rounded-xl flex items-center justify-center border-2 border-dashed border-outline-variant/30">
                    <HelpCircle className="text-outline-variant w-10 h-10" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interaction Sidebar */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            <h3 className="text-on-surface-variant font-bold text-sm tracking-widest uppercase px-2">Select Solution</h3>
            <div className="grid grid-cols-2 gap-4">
              {/* Option A */}
              <button 
                onClick={() => setSelectedOption('A')}
                className={`group p-6 rounded-3xl transition-all duration-300 shadow-sm hover:shadow-md border-b-4 active:scale-95 text-left ${selectedOption === 'A' ? 'bg-white border-primary ring-2 ring-primary/10' : 'bg-surface-container-lowest hover:bg-white border-transparent'}`}
              >
                <div className="flex justify-between items-start mb-4">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${selectedOption === 'A' ? 'bg-primary text-white' : 'bg-surface-container text-primary group-hover:bg-primary group-hover:text-white'}`}>A</span>
                  {selectedOption === 'A' && <CheckCircle className="text-primary w-5 h-5 fill-current" />}
                </div>
                <div className="flex justify-center py-4">
                  <img className={`w-14 h-14 ${selectedOption === 'A' ? '' : 'opacity-70'}`} src="https://lh3.googleusercontent.com/aida-public/AB6AXuD6dOGyRvw8UaSlfVbQsWfoKOiCW_4SEg2rTCETrMfcOT1C5FDS_tzB-XA1NxgblUBCuQ-5_SEigig2JJqgfdPvrORZlaxQDwLgghCHKXECh5GWITuS2lorxxT6ecXYfCrGdWRKdi3axw2fat6813-xWjtZMMGP0xwLZEuK8G5Xa9PedxL6AoIpd_Uvgv_tzODT5er9uEVp2btW-4-3iIhqB3r0ygCKC4JI2xcbmq4z3otBpgZdWeB3jqqEHM5PBU7Z_3cFYtFyeNs" />
                </div>
              </button>

              {/* Option B */}
              <button 
                onClick={() => setSelectedOption('B')}
                className={`group p-6 rounded-3xl transition-all duration-300 shadow-sm hover:shadow-md border-b-4 active:scale-95 text-left relative overflow-hidden ${selectedOption === 'B' ? 'bg-white border-primary ring-2 ring-primary/10' : 'bg-surface-container-lowest hover:bg-white border-transparent'}`}
              >
                {selectedOption === 'B' && (
                  <div className="absolute top-0 right-0 p-2">
                    <CheckCircle className="text-primary w-5 h-5 fill-current" />
                  </div>
                )}
                <div className="flex justify-between items-start mb-4">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${selectedOption === 'B' ? 'bg-primary text-white' : 'bg-surface-container text-primary group-hover:bg-primary group-hover:text-white'}`}>B</span>
                </div>
                <div className="flex justify-center py-4">
                  <img className={`w-14 h-14 ${selectedOption === 'B' ? '' : 'opacity-70'}`} src="https://lh3.googleusercontent.com/aida-public/AB6AXuAw7oqTLzC1AdCkfLcjS9Fp1TFtb0OmQs7Q2T1d_Otfl0DhsN807glZbVVkY5CDedGNdRZi2JSdEmiYfrYQ4gTBE44tCZPXsDXOZvZTAJo8c7VLNGNykrTe2Xu5cgrXqKc3rWQf6FbxG0YtT5Pk1VkTjFJ5olYVtYxbKSwFt27xR-BgU6Qp8lZx4F0_KrtvsDugg5nFmFARD5kU1aiC-fdZYQDlYYo1grS8X_msc5NoV8qvZDKT9G5U9_l8bS6nITzxkkv-zH4UunM" />
                </div>
              </button>

              {/* Option C */}
              <button 
                onClick={() => setSelectedOption('C')}
                className={`group p-6 rounded-3xl transition-all duration-300 shadow-sm hover:shadow-md border-b-4 active:scale-95 text-left ${selectedOption === 'C' ? 'bg-white border-primary ring-2 ring-primary/10' : 'bg-surface-container-lowest hover:bg-white border-transparent'}`}
              >
                <div className="flex justify-between items-start mb-4">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${selectedOption === 'C' ? 'bg-primary text-white' : 'bg-surface-container text-primary group-hover:bg-primary group-hover:text-white'}`}>C</span>
                  {selectedOption === 'C' && <CheckCircle className="text-primary w-5 h-5 fill-current" />}
                </div>
                <div className="flex justify-center py-4">
                  <img className={`w-14 h-14 ${selectedOption === 'C' ? '' : 'opacity-70'}`} src="https://lh3.googleusercontent.com/aida-public/AB6AXuA9f4y8pqkwxAmA3e4xhzZeeM5zaH7WnEeyBp8w2_pS7lP149vNY2NkqbSpAaXtX32rKVN4IYmUj5k-ymYVf1xlmfeNdNSdXKDNTYTBQYzgVSCefFZaExLmKwxDpAcVhdiMhJj_Ll3z7z-bbTfBUwVuREBAA-LDd_TUdMPIqEOnAJkY0gSd-Say6uOswuDYuNO7t7eETCXmhwwH4Tf0SQbi_kFWwBf7tU7VolR_WZ9uu0-Y30v9GgsaiIE0iaP9Rs0kQc-17prDMQQ" />
                </div>
              </button>

              {/* Option D */}
              <button 
                onClick={() => setSelectedOption('D')}
                className={`group p-6 rounded-3xl transition-all duration-300 shadow-sm hover:shadow-md border-b-4 active:scale-95 text-left ${selectedOption === 'D' ? 'bg-white border-primary ring-2 ring-primary/10' : 'bg-surface-container-lowest hover:bg-white border-transparent'}`}
              >
                <div className="flex justify-between items-start mb-4">
                  <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${selectedOption === 'D' ? 'bg-primary text-white' : 'bg-surface-container text-primary group-hover:bg-primary group-hover:text-white'}`}>D</span>
                  {selectedOption === 'D' && <CheckCircle className="text-primary w-5 h-5 fill-current" />}
                </div>
                <div className="flex justify-center py-4">
                  <img className={`w-14 h-14 ${selectedOption === 'D' ? '' : 'opacity-70'}`} src="https://lh3.googleusercontent.com/aida-public/AB6AXuBZId0rScfqmjtH0oro_M0uS6INJ3r09Gdx_ewBrhKv-DG8hUrd2xJNFLVEEj7VGHJI9vr-Notd67S_DANmwF4vh-Bvww-aPyrJQtMVq5yrqe14xjsGQRSEnHPy5a1isScO6VoC8oX6M8TBZN9ZrIyBjwMIdvaVOiy-xy1nqs4Ihu-HFrex3kLENihTYG2ix06yD4xvOOnKzawkTsgjoW1CQ3fVvTXo0bV16KpGvAvtW0d0JofTTOlB8G0i_nisMYGZhvkgqLLjl0c" />
                </div>
              </button>
            </div>

            {/* Action Controls */}
            <div className="mt-8 flex flex-col gap-4">
              <button 
                onClick={() => navigate('/analysis')}
                className="w-full py-5 bg-gradient-to-br from-primary to-primary-container text-white font-bold rounded-2xl shadow-xl shadow-primary/20 flex items-center justify-center gap-3 active:scale-[0.98] transition-transform"
              >
                Confirm Selection
                <ArrowRight className="w-5 h-5" />
              </button>
              <button className="w-full py-4 text-primary font-semibold flex items-center justify-center gap-2 hover:bg-primary/5 rounded-xl transition-colors">
                <Flag className="w-5 h-5" />
                Mark for Review
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* BottomNavBar (Mobile only) */}
      <nav className="md:hidden fixed bottom-0 w-full rounded-t-3xl z-50 bg-white dark:bg-slate-900 border-t border-outline-variant/15 shadow-[0_-4px_24px_-4px_rgba(7,30,39,0.06)] px-4 pb-6 pt-3 flex justify-around items-center">
        <button className="flex flex-col items-center justify-center bg-surface-container-low dark:bg-blue-900/30 text-primary dark:text-blue-300 rounded-2xl px-5 py-2 active:scale-90 transition-transform duration-150">
          <Brain className="w-6 h-6 fill-current" />
          <span className="font-sans text-xs font-medium mt-1">Assessments</span>
        </button>
        <button 
          onClick={() => navigate('/results')}
          className="flex flex-col items-center justify-center text-on-surface-variant dark:text-slate-500 px-5 py-2 hover:text-primary active:scale-90 transition-transform duration-150"
        >
          <BarChart2 className="w-6 h-6" />
          <span className="font-sans text-xs font-medium mt-1">Insights</span>
        </button>
        <button 
          onClick={() => navigate('/logout')}
          className="flex flex-col items-center justify-center text-on-surface-variant dark:text-slate-500 px-5 py-2 hover:text-primary active:scale-90 transition-transform duration-150"
        >
          <User className="w-6 h-6" />
          <span className="font-sans text-xs font-medium mt-1">Profile</span>
        </button>
      </nav>

      {/* FAB for Next */}
      <button 
        onClick={() => navigate('/analysis')}
        className="fixed bottom-10 right-10 hidden md:flex w-16 h-16 bg-primary-container text-white rounded-full items-center justify-center shadow-[0_12px_32px_-4px_rgba(7,30,39,0.25)] hover:scale-110 active:scale-95 transition-all z-40"
      >
        <ChevronRight className="w-8 h-8" />
      </button>
    </div>
  );
}
