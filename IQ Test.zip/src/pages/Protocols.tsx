import { Shield, Timer, ClipboardCheck, VolumeX, MonitorOff, FileEdit, UserCheck, Clock, ArrowRight, Lightbulb, Brain, BarChart2, History, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Protocols() {
  const navigate = useNavigate();

  return (
    <div className="bg-surface text-on-surface min-h-screen flex flex-col">
      {/* TopAppBar */}
      <header className="fixed top-0 w-full z-50 bg-surface/80 dark:bg-slate-950/80 backdrop-blur-md shadow-[0_24px_32px_-4px_rgba(7,30,39,0.06)] flex justify-between items-center px-6 h-16">
        <div className="flex items-center gap-3">
          <Shield className="text-primary w-6 h-6" />
          <span className="text-lg font-extrabold tracking-tighter text-on-background font-sans">IQ ACADEMY</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex gap-8">
            <a className="text-primary border-b-2 border-primary font-sans font-bold tracking-tight" href="#">Assess</a>
            <a className="text-on-surface-variant hover:bg-white/50 transition-colors font-sans font-bold tracking-tight" href="#">Insights</a>
            <a className="text-on-surface-variant hover:bg-white/50 transition-colors font-sans font-bold tracking-tight" href="#">Archive</a>
          </div>
          <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center overflow-hidden border border-white/20">
            <img alt="User Avatar" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDtx1gvdB-5D9yRCagNqMpLKY9Azr_vlk8EV3MeUnNCvfycSiP-FUKxTvKj37W3I_1F5dZBd4sT6SGEljycgJEAna_vg8dsDzo_7JEcG4L32A2ZNbIxZCoX_QmjyAgpmxDpFcQtLvKSQA290r_aJ65BR3SivFHpJFS8_hZYRvwO3ZTMRVnbJ7Pq8T33YwXzKQLhmKqBVsKmUaZ8spYby5kshM4BavK0sHB4uq-n2zVl6crFQ_HVOK-B09FytCPAs46ythdAJ1dYa_E" />
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-grow pt-24 pb-32 px-6 max-w-5xl mx-auto w-full">
        {/* Header Section: Asymmetric Editorial Layout */}
        <div className="mb-16 md:mb-24 flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div className="max-w-xl">
            <p className="text-primary font-bold tracking-widest text-sm mb-4 uppercase">Academic Standard 4.2</p>
            <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-on-background leading-tight">
              Assessment Protocols
            </h1>
            <p className="mt-6 text-on-surface-variant text-lg leading-relaxed">
              Prepare your mental environment for maximum cognitive performance. These guidelines ensure the integrity and accuracy of your IQ quantification.
            </p>
          </div>
          <div className="hidden md:block">
            <div className="bg-surface-container-lowest p-8 rounded-xl shadow-sm border-l-4 border-primary">
              <Timer className="text-primary w-10 h-10 mb-4" />
              <div className="text-on-surface-variant text-sm font-semibold uppercase tracking-wider">Total Duration</div>
              <div className="text-3xl font-bold text-on-surface">45 Minutes</div>
            </div>
          </div>
        </div>

        {/* Instructions Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Rules Checklist (Large Span) */}
          <section className="md:col-span-8 bg-surface-container-lowest p-8 md:p-12 rounded-[2rem] shadow-sm relative overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-2xl font-bold mb-8 text-on-surface flex items-center gap-3">
                <ClipboardCheck className="text-secondary w-6 h-6" />
                Integrity Standards
              </h2>
              <ul className="space-y-6">
                <li className="flex items-start gap-4 p-4 rounded-xl hover:bg-surface-container-low transition-colors duration-300">
                  <VolumeX className="text-secondary w-6 h-6 mt-1 shrink-0" />
                  <div>
                    <h3 className="font-bold text-on-surface">Controlled Environment</h3>
                    <p className="text-on-surface-variant text-sm mt-1">Ensure a quiet, private space free from external interruptions or auditory distractions.</p>
                  </div>
                </li>
                <li className="flex items-start gap-4 p-4 rounded-xl hover:bg-surface-container-low transition-colors duration-300">
                  <MonitorOff className="text-secondary w-6 h-6 mt-1 shrink-0" />
                  <div>
                    <h3 className="font-bold text-on-surface">Singular Interface</h3>
                    <p className="text-on-surface-variant text-sm mt-1">External aids, calculators, or secondary search windows are strictly prohibited during the session.</p>
                  </div>
                </li>
                <li className="flex items-start gap-4 p-4 rounded-xl hover:bg-surface-container-low transition-colors duration-300">
                  <FileEdit className="text-secondary w-6 h-6 mt-1 shrink-0" />
                  <div>
                    <h3 className="font-bold text-on-surface">Draft Materials</h3>
                    <p className="text-on-surface-variant text-sm mt-1">You may utilize physical scratch paper and a pencil for pattern visualization and logical deduction.</p>
                  </div>
                </li>
                <li className="flex items-start gap-4 p-4 rounded-xl hover:bg-surface-container-low transition-colors duration-300">
                  <UserCheck className="text-secondary w-6 h-6 mt-1 shrink-0" />
                  <div>
                    <h3 className="font-bold text-on-surface">Unassisted Effort</h3>
                    <p className="text-on-surface-variant text-sm mt-1">The assessment must reflect your individual cognitive capacity without collaboration.</p>
                  </div>
                </li>
              </ul>
            </div>
            {/* Subtle Gradient Background Element */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full -mr-20 -mt-20 blur-3xl"></div>
          </section>

          {/* Metrics & Start (Small Span) */}
          <section className="md:col-span-4 flex flex-col gap-6">
            {/* Mobile Time Limit Card (Visible only on mobile) */}
            <div className="md:hidden bg-primary-container p-8 rounded-[2rem] text-on-primary-container">
              <div className="flex items-center justify-between mb-4">
                <Clock className="w-10 h-10" />
                <span className="bg-white/20 px-3 py-1 rounded-full text-xs font-bold">LIVE TIMER</span>
              </div>
              <div className="text-sm opacity-80 uppercase tracking-widest font-bold">Total Time</div>
              <div className="text-4xl font-extrabold mt-1">45:00</div>
            </div>

            {/* Session Context Card */}
            <div className="bg-surface-container p-8 rounded-[2rem] flex flex-col justify-between flex-grow">
              <div>
                <h3 className="text-on-surface font-bold text-lg mb-4">Session Scope</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-on-surface-variant text-sm">Quantified Domains</span>
                    <span className="text-primary font-bold">6</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-on-surface-variant text-sm">Total Inquiries</span>
                    <span className="text-primary font-bold">40</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-on-surface-variant text-sm">Adaptive Difficulty</span>
                    <span className="text-secondary font-bold">Active</span>
                  </div>
                </div>
              </div>
              <div className="mt-8 pt-8 border-t border-outline-variant/20">
                <p className="text-xs text-on-surface-variant leading-relaxed">
                  Once initiated, the session cannot be paused. Ensure your connectivity is stable and your device is adequately powered.
                </p>
              </div>
            </div>

            {/* Action Card */}
            <div className="bg-surface-container-lowest p-2 rounded-[2.5rem] shadow-lg border border-white/50">
              <button 
                onClick={() => navigate('/assessment')}
                className="w-full bg-gradient-to-br from-primary to-primary-container text-on-primary py-6 px-8 rounded-[2rem] font-bold text-xl flex items-center justify-center gap-3 active:scale-95 transition-all duration-200 shadow-[0_12px_24px_-8px_rgba(0,93,172,0.4)]"
              >
                Begin Assessment
                <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          </section>
        </div>

        {/* Pro-tip/Warning Section */}
        <div className="mt-12 p-8 bg-secondary-container/30 rounded-[2rem] flex flex-col md:flex-row items-center gap-6">
          <div className="w-16 h-16 rounded-full bg-secondary-container flex items-center justify-center shrink-0">
            <Lightbulb className="text-on-secondary-container w-8 h-8 fill-current" />
          </div>
          <div>
            <h4 className="font-bold text-on-secondary-container">Pro-Tip: Cognitive Pacing</h4>
            <p className="text-on-secondary-container/80 text-sm mt-1">
              Do not linger excessively on complex patterns. Use the "Mark for Review" feature to revisit challenging items if time permits at the conclusion of the assessment.
            </p>
          </div>
        </div>
      </main>

      {/* BottomNavBar (Mobile Only) */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 pb-6 pt-3 bg-surface/80 backdrop-blur-xl shadow-[0_-8px_24px_rgba(7,30,39,0.04)] rounded-t-3xl border-t border-white/20">
        <button className="flex flex-col items-center justify-center bg-white text-primary rounded-2xl px-5 py-1.5 shadow-sm transition-all duration-300 ease-out">
          <Brain className="w-6 h-6 fill-current" />
          <span className="text-[11px] font-semibold font-sans mt-1">Assess</span>
        </button>
        <button 
          onClick={() => navigate('/results')}
          className="flex flex-col items-center justify-center text-on-surface-variant px-5 py-1.5 hover:text-primary transition-all duration-300 ease-out"
        >
          <BarChart2 className="w-6 h-6" />
          <span className="text-[11px] font-semibold font-sans mt-1">Insights</span>
        </button>
        <button className="flex flex-col items-center justify-center text-on-surface-variant px-5 py-1.5 hover:text-primary transition-all duration-300 ease-out">
          <History className="w-6 h-6" />
          <span className="text-[11px] font-semibold font-sans mt-1">Archive</span>
        </button>
        <button 
          onClick={() => navigate('/logout')}
          className="flex flex-col items-center justify-center text-on-surface-variant px-5 py-1.5 hover:text-primary transition-all duration-300 ease-out"
        >
          <User className="w-6 h-6" />
          <span className="text-[11px] font-semibold font-sans mt-1">Profile</span>
        </button>
      </nav>
    </div>
  );
}
