import { Menu, ArrowRight, Lightbulb, Brain, Timer, BadgeCheck, FileText, LineChart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Welcome() {
  const navigate = useNavigate();

  return (
    <div className="bg-background text-on-background min-h-screen flex flex-col">
      {/* TopAppBar */}
      <header className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md flex justify-between items-center px-6 py-4">
        <div className="flex items-center gap-4">
          <button className="text-primary active:scale-95 duration-200">
            <Menu className="w-6 h-6" />
          </button>
          <h1 className="font-sans tracking-tight font-extrabold text-xl text-primary">IQ Sanctuary</h1>
        </div>
        <div className="h-10 w-10 rounded-full bg-surface-container-highest overflow-hidden active:scale-95 duration-200 transition-transform">
          <img alt="Student Profile" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA6PfazIDPepQy9GHvzxWoq_kzS4-wwvogFW0iwpYDXhf8kmnK3TtTFJ4_DxQyIFx0Aqr6dLI9Cal737-Se3U4QPBCufBWQO00rXHErk9F1cbD4YyKyQ9RJyqqCfNffHGP8bcCwpRJ3XgRcgKmH17Ir3A-CZB7mqwxePLCklDxLwCBQ0_Cxrf_nmtiZxzlonNXzq9LUUkNy_mArAnIoKqM-0wTzqXVe_-aDhRYiXSgaJ5o4gMjgaEpBLrwLrDcY5Cnd1MsriaCLO14" />
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-grow flex flex-col items-center justify-center px-6 pt-24 pb-32">
        <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Hero Content: Asymmetric Layout */}
          <div className="md:col-span-7 space-y-8">
            <div className="space-y-2">
              <span className="text-secondary font-semibold tracking-wider text-sm uppercase px-4 py-1.5 bg-secondary-container/30 rounded-full inline-block">Welcome back, Alex</span>
              <h2 className="text-5xl md:text-6xl font-extrabold text-on-background leading-[1.1] tracking-tight">
                Ready to explore your <span className="text-primary">potential?</span>
              </h2>
            </div>
            <p className="text-on-surface-variant text-lg md:text-xl leading-relaxed max-w-lg">
              Step into a space designed for focus. Our cognitive assessments help you understand your unique thinking patterns in a calm, pressure-free environment.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button 
                onClick={() => navigate('/protocols')}
                className="bg-gradient-to-br from-primary to-primary-container text-on-primary px-8 py-4 rounded-xl font-bold text-lg shadow-[0_24px_32px_-4px_rgba(7,30,39,0.06)] hover:translate-y-[-2px] active:scale-95 transition-all duration-200 flex items-center justify-center gap-3"
              >
                Start Test
                <ArrowRight className="w-5 h-5" />
              </button>
              <button 
                onClick={() => navigate('/results')}
                className="text-primary font-bold px-8 py-4 rounded-xl hover:bg-surface-container-low transition-colors duration-200 flex items-center justify-center gap-2"
              >
                View Past Insights
              </button>
            </div>
          </div>

          {/* Visual Feature: Bento Style Card */}
          <div className="md:col-span-5 relative">
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-secondary/10 rounded-full blur-2xl"></div>
            <div className="relative bg-surface-container-lowest p-8 rounded-[2rem] shadow-[0_24px_32px_-4px_rgba(7,30,39,0.06)] border border-white/40">
              <div className="space-y-6">
                {/* Stat Item 1 */}
                <div className="flex items-center gap-4 p-4 bg-surface-container-low rounded-2xl">
                  <div className="h-12 w-12 rounded-xl bg-white flex items-center justify-center text-primary shadow-sm">
                    <Lightbulb className="w-6 h-6 fill-current" />
                  </div>
                  <div>
                    <p className="text-xs text-on-surface-variant font-medium">Daily Goal</p>
                    <p className="font-bold text-on-background">15 Logic Puzzles</p>
                  </div>
                </div>

                {/* Stat Item 2: Progress Gauge */}
                <div className="space-y-3">
                  <div className="flex justify-between items-end">
                    <p className="text-sm font-semibold text-on-background">Cognitive Stamina</p>
                    <p className="text-xs font-bold text-secondary">Level 12</p>
                  </div>
                  <div className="h-3 w-full bg-surface-container-highest rounded-full overflow-hidden">
                    <div className="h-full bg-secondary w-3/4 rounded-full"></div>
                  </div>
                </div>

                {/* Mini Card */}
                <div className="p-6 bg-gradient-to-br from-surface-container-low to-surface-container rounded-2xl">
                  <p className="text-sm italic text-on-surface-variant leading-relaxed">
                    "The measure of intelligence is the ability to change."
                  </p>
                  <p className="text-xs font-bold text-primary mt-3">— Albert Einstein</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Secondary Info Clusters */}
        <div className="max-w-4xl w-full mt-24 grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors duration-300">
            <Brain className="text-primary w-6 h-6 mb-3" />
            <h4 className="font-bold text-on-background mb-1">Adaptive Logic</h4>
            <p className="text-sm text-on-surface-variant">Questions that evolve with your unique solving style.</p>
          </div>
          <div className="p-6 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors duration-300">
            <Timer className="text-primary w-6 h-6 mb-3" />
            <h4 className="font-bold text-on-background mb-1">Paced Rounds</h4>
            <p className="text-sm text-on-surface-variant">No ticking clocks. We measure focus, not just speed.</p>
          </div>
          <div className="p-6 rounded-2xl bg-surface-container-low hover:bg-surface-container transition-colors duration-300">
            <BadgeCheck className="text-primary w-6 h-6 mb-3" />
            <h4 className="font-bold text-on-background mb-1">Verified Metrics</h4>
            <p className="text-sm text-on-surface-variant">Scientific scoring aligned with global standards.</p>
          </div>
        </div>
      </main>

      {/* BottomNavBar */}
      <nav className="fixed bottom-0 left-0 w-full flex justify-around items-center pb-safe pt-2 px-4 bg-white/80 backdrop-blur-md rounded-t-[1.5rem] z-50 shadow-[0_-4px_24px_-4px_rgba(7,30,39,0.06)] border-t border-outline-variant/15">
        <button className="flex flex-col items-center justify-center bg-surface-container-low text-primary rounded-2xl px-5 py-2 active:scale-90 duration-200">
          <Brain className="w-6 h-6 fill-current" />
          <span className="font-sans text-xs font-medium mt-1">Practice</span>
        </button>
        <button 
          onClick={() => navigate('/protocols')}
          className="flex flex-col items-center justify-center text-on-surface-variant px-5 py-2 hover:text-primary active:scale-90 duration-200"
        >
          <FileText className="w-6 h-6" />
          <span className="font-sans text-xs font-medium mt-1">Test</span>
        </button>
        <button 
          onClick={() => navigate('/results')}
          className="flex flex-col items-center justify-center text-on-surface-variant px-5 py-2 hover:text-primary active:scale-90 duration-200"
        >
          <LineChart className="w-6 h-6" />
          <span className="font-sans text-xs font-medium mt-1">Insights</span>
        </button>
      </nav>

      {/* Floating Decorative Element */}
      <div className="fixed top-1/4 -left-20 w-40 h-40 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="fixed bottom-1/4 -right-20 w-60 h-60 bg-secondary/5 rounded-full blur-3xl pointer-events-none"></div>
    </div>
  );
}
