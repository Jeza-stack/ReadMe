import React from 'react';
import { Gem, Globe, ShieldCheck, Lock, Badge, Key, ArrowRight, HelpCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    navigate('/welcome');
  };

  return (
    <div className="bg-surface text-on-surface min-h-screen flex flex-col">
      {/* TopAppBar Execution */}
      <header className="fixed top-0 w-full z-50 bg-surface/80 backdrop-blur-[20px] shadow-sm shadow-on-background/5">
        <div className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <Gem className="text-primary w-6 h-6" />
            <h1 className="text-xl font-bold text-on-background tracking-tight">IQ Global Standard</h1>
          </div>
          <div className="hidden md:flex gap-6 items-center">
            <span className="text-on-surface-variant text-sm font-medium">System Status: Secure</span>
            <div className="w-8 h-8 rounded-full bg-surface-container-high flex items-center justify-center">
              <Globe className="w-4 h-4 text-primary" />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Canvas */}
      <main className="flex-grow flex items-center justify-center px-4 pt-24 pb-12">
        <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Branding/Editorial Column */}
          <div className="lg:col-span-6 space-y-8 hidden lg:block">
            <div className="space-y-4">
              <span className="inline-block px-4 py-1.5 rounded-full bg-secondary-container text-on-secondary-container text-xs font-bold tracking-wider uppercase">Institutional Access</span>
              <h2 className="text-5xl font-extrabold text-on-background leading-tight tracking-tight">
                The Intellectual <br />
                <span className="text-primary">Sanctuary.</span>
              </h2>
              <p className="text-on-surface-variant text-lg max-w-md leading-relaxed">
                Welcome to the global benchmark for cognitive assessment. Please verify your credentials to access your testing environment.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-6 rounded-3xl bg-surface-container-low">
                <ShieldCheck className="text-primary w-6 h-6 mb-3" />
                <h4 className="font-bold text-on-background">ISO Certified</h4>
                <p className="text-xs text-on-surface-variant mt-1">Standardized global metrics</p>
              </div>
              <div className="p-6 rounded-3xl bg-surface-container-low">
                <Lock className="text-primary w-6 h-6 mb-3" />
                <h4 className="font-bold text-on-background">Encrypted</h4>
                <p className="text-xs text-on-surface-variant mt-1">End-to-end data protection</p>
              </div>
            </div>
          </div>

          {/* Authentication Card */}
          <div className="lg:col-span-6 flex justify-center z-10">
            <div className="w-full max-w-md bg-surface-container-lowest p-8 md:p-12 rounded-3xl shadow-[0_24px_48px_-12px_rgba(7,30,39,0.08)]">
              <div className="mb-10 lg:hidden text-center">
                <h2 className="text-3xl font-bold text-on-background">Sign In</h2>
                <p className="text-on-surface-variant mt-2">Enter your institutional credentials</p>
              </div>
              <form className="space-y-8" onSubmit={handleLogin}>
                {/* ID Field */}
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-on-surface-variant px-1">Candidate ID</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Badge className="text-outline w-5 h-5 group-focus-within:text-primary transition-colors" />
                    </div>
                    <input className="w-full pl-12 pr-4 py-4 bg-surface-container-low border-none rounded-2xl focus:ring-0 focus:bg-surface-container-lowest transition-all duration-300 placeholder:text-outline/50 border-b-2 border-transparent focus:border-primary outline-none" placeholder="e.g. IQ-992-001" type="text" />
                  </div>
                </div>

                {/* Access Code Field */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center px-1">
                    <label className="text-sm font-semibold text-on-surface-variant">Access Code</label>
                    <a className="text-xs font-bold text-primary hover:underline" href="#">Forgot Code?</a>
                  </div>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Key className="text-outline w-5 h-5 group-focus-within:text-primary transition-colors" />
                    </div>
                    <input className="w-full pl-12 pr-4 py-4 bg-surface-container-low border-none rounded-2xl focus:ring-0 focus:bg-surface-container-lowest transition-all duration-300 placeholder:text-outline/50 border-b-2 border-transparent focus:border-primary outline-none" placeholder="••••••••" type="password" />
                  </div>
                </div>

                {/* Submit Button */}
                <button className="w-full py-4 px-6 bg-gradient-to-br from-primary to-primary-container text-on-primary font-bold text-lg rounded-3xl shadow-xl shadow-primary/20 active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2 group" type="submit">
                  Verify Identity
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>

                {/* Secondary Links */}
                <div className="pt-6 text-center space-y-4">
                  <p className="text-sm text-on-surface-variant">
                    New candidate? <a className="text-primary font-bold hover:underline" href="#">Request access</a>
                  </p>
                  <div className="flex items-center justify-center gap-6 pt-4 border-t border-outline-variant/15">
                    <button className="text-xs font-medium text-on-surface-variant flex items-center gap-1 hover:text-primary transition-colors" type="button">
                      <HelpCircle className="w-4 h-4" /> Support
                    </button>
                    <button className="text-xs font-medium text-on-surface-variant flex items-center gap-1 hover:text-primary transition-colors" type="button">
                      <Globe className="w-4 h-4" /> Language
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>

      {/* Professional Footer */}
      <footer className="mt-auto py-8 px-6 z-10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] md:text-xs text-outline font-medium tracking-widest uppercase">
          <p>© 2024 IQ Global Standard Institutional Services</p>
          <div className="flex gap-8">
            <a className="hover:text-primary transition-colors" href="#">Privacy Protocol</a>
            <a className="hover:text-primary transition-colors" href="#">Security Standards</a>
            <a className="hover:text-primary transition-colors" href="#">Terms of Entry</a>
          </div>
        </div>
      </footer>

      {/* Decorative Elements */}
      <div className="fixed top-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary/5 rounded-full blur-[120px] -z-10"></div>
      <div className="fixed bottom-[-10%] left-[-10%] w-[30%] h-[30%] bg-secondary-fixed/10 rounded-full blur-[100px] -z-10"></div>
    </div>
  );
}
