import { ArrowLeft, MoreVertical, CheckCircle, XCircle, Clock, TrendingUp, Download, Share2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Results() {
  const navigate = useNavigate();

  return (
    <div className="bg-surface text-on-surface min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="w-full top-0 sticky z-40 bg-surface-container-low dark:bg-slate-800 backdrop-blur-md">
        <div className="flex items-center justify-between px-6 py-4 w-full">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate('/welcome')}
              className="text-primary dark:text-blue-400 hover:bg-white/50 dark:hover:bg-slate-700 transition-colors active:scale-95 duration-200 p-2 rounded-full"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="font-sans tracking-tight font-bold text-xl text-primary dark:text-blue-400">Assessment Results</h1>
          </div>
          <button className="text-primary dark:text-blue-400 hover:bg-white/50 dark:hover:bg-slate-700 transition-colors active:scale-95 duration-200 p-2 rounded-full">
            <MoreVertical className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        {/* Overall Score Section */}
        <section className="mb-12 text-center">
          <div className="inline-block bg-surface-container-lowest p-12 rounded-[3rem] shadow-[0_32px_64px_-16px_rgba(7,30,39,0.1)] border border-outline-variant/5">
            <h2 className="text-sm font-extrabold uppercase tracking-[0.3em] text-on-surface-variant mb-6">Global Standard Score</h2>
            <div className="text-8xl font-black tracking-tighter text-primary mb-4 drop-shadow-sm">132</div>
            <p className="text-xl font-medium text-secondary">98th Percentile</p>
            <div className="mt-8 flex justify-center gap-4">
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 text-sm font-bold tracking-wide">
                <CheckCircle className="w-4 h-4" /> Superior Range
              </span>
            </div>
          </div>
        </section>

        {/* Detailed Metrics Grid */}
        <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Metric Card 1 */}
          <div className="bg-surface-container p-6 rounded-[2rem] border border-outline-variant/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Accuracy</h3>
              <CheckCircle className="text-green-600 dark:text-green-400 w-5 h-5" />
            </div>
            <div className="text-3xl font-extrabold text-on-surface mb-1">94%</div>
            <p className="text-sm text-on-surface-variant">33/35 Correct</p>
          </div>

          {/* Metric Card 2 */}
          <div className="bg-surface-container p-6 rounded-[2rem] border border-outline-variant/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Errors</h3>
              <XCircle className="text-red-500 dark:text-red-400 w-5 h-5" />
            </div>
            <div className="text-3xl font-extrabold text-on-surface mb-1">2</div>
            <p className="text-sm text-on-surface-variant">Pattern Recognition</p>
          </div>

          {/* Metric Card 3 */}
          <div className="bg-surface-container p-6 rounded-[2rem] border border-outline-variant/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Avg Time</h3>
              <Clock className="text-secondary w-5 h-5" />
            </div>
            <div className="text-3xl font-extrabold text-on-surface mb-1">42s</div>
            <p className="text-sm text-on-surface-variant">Per Question</p>
          </div>

          {/* Metric Card 4 */}
          <div className="bg-surface-container p-6 rounded-[2rem] border border-outline-variant/10">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant">Pacing</h3>
              <TrendingUp className="text-primary w-5 h-5" />
            </div>
            <div className="text-3xl font-extrabold text-on-surface mb-1">Optimal</div>
            <p className="text-sm text-on-surface-variant">Consistent Speed</p>
          </div>
        </section>

        {/* Domain Breakdown */}
        <section className="mb-12">
          <h3 className="text-2xl font-bold tracking-tight text-on-surface mb-6">Domain Breakdown</h3>
          <div className="bg-surface-container-lowest rounded-[2.5rem] p-8 shadow-sm border border-outline-variant/10 space-y-8">
            
            {/* Domain Item 1 */}
            <div>
              <div className="flex justify-between items-end mb-2">
                <span className="font-semibold text-lg">Matrix Reasoning</span>
                <span className="font-bold text-primary">100%</span>
              </div>
              <div className="w-full bg-surface-container-high rounded-full h-3 overflow-hidden">
                <div className="bg-primary h-3 rounded-full" style={{ width: '100%' }}></div>
              </div>
            </div>

            {/* Domain Item 2 */}
            <div>
              <div className="flex justify-between items-end mb-2">
                <span className="font-semibold text-lg">Spatial Visualization</span>
                <span className="font-bold text-primary">90%</span>
              </div>
              <div className="w-full bg-surface-container-high rounded-full h-3 overflow-hidden">
                <div className="bg-primary h-3 rounded-full" style={{ width: '90%' }}></div>
              </div>
            </div>

            {/* Domain Item 3 */}
            <div>
              <div className="flex justify-between items-end mb-2">
                <span className="font-semibold text-lg">Logical Synthesis</span>
                <span className="font-bold text-secondary">85%</span>
              </div>
              <div className="w-full bg-surface-container-high rounded-full h-3 overflow-hidden">
                <div className="bg-secondary h-3 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>

          </div>
        </section>

        {/* Action Buttons */}
        <section className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="flex items-center justify-center gap-3 bg-primary text-on-primary px-8 py-4 rounded-full font-bold tracking-wide hover:bg-primary/90 active:scale-95 transition-all shadow-lg shadow-primary/20">
            <Download className="w-5 h-5" />
            Download Report
          </button>
          <button 
            onClick={() => navigate('/analysis')}
            className="flex items-center justify-center gap-3 bg-surface-container-high text-on-surface px-8 py-4 rounded-full font-bold tracking-wide hover:bg-surface-container-highest active:scale-95 transition-all border border-outline-variant/20"
          >
            <TrendingUp className="w-5 h-5" />
            View Analysis
          </button>
        </section>

      </main>

      {/* BottomNavBar Shell */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 pb-8 pt-4 bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl rounded-t-[1.5rem] shadow-[0_-4px_24px_rgba(7,30,39,0.06)]">
        {/* Share Result */}
        <button className="flex flex-col items-center justify-center text-on-surface-variant dark:text-slate-400 px-6 py-2 hover:bg-surface-container-low dark:hover:bg-slate-800 active:scale-[0.98] transition-transform rounded-2xl">
          <Share2 className="w-6 h-6 mb-1" />
          <span className="text-xs font-semibold uppercase tracking-wider">Share</span>
        </button>

        {/* Return Home */}
        <button 
          onClick={() => navigate('/welcome')}
          className="flex flex-col items-center justify-center bg-secondary-container dark:bg-teal-900 text-on-secondary-container dark:text-teal-100 rounded-2xl px-8 py-3 active:scale-[0.98] transition-transform shadow-lg shadow-secondary/10"
        >
          <ArrowLeft className="w-6 h-6 mb-1" />
          <span className="text-xs font-semibold uppercase tracking-wider">Home</span>
        </button>
      </nav>
    </div>
  );
}
