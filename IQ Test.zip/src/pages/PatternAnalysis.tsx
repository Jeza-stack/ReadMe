import { ArrowLeft, MoreVertical, Brain, Lightbulb, History, CheckCircle, Play } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PatternAnalysis() {
  const navigate = useNavigate();

  return (
    <div className="bg-surface text-on-surface min-h-screen pb-32">
      {/* TopAppBar */}
      <header className="w-full top-0 sticky z-40 bg-surface-container-low dark:bg-slate-800 backdrop-blur-md">
        <div className="flex items-center justify-between px-6 py-4 w-full">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate(-1)}
              className="text-primary dark:text-blue-400 hover:bg-white/50 dark:hover:bg-slate-700 transition-colors active:scale-95 duration-200 p-2 rounded-full"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="font-sans tracking-tight font-bold text-xl text-primary dark:text-blue-400">Pattern Analysis</h1>
          </div>
          <button className="text-primary dark:text-blue-400 hover:bg-white/50 dark:hover:bg-slate-700 transition-colors active:scale-95 duration-200 p-2 rounded-full">
            <MoreVertical className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-8">
        {/* Brand Identity Intro */}
        <div className="mb-10 text-left">
          <span className="text-primary font-bold tracking-widest text-xs uppercase mb-2 block">Lumina Academy</span>
          <h2 className="text-4xl font-extrabold tracking-tight text-on-surface mb-4">Intellectual Sanctuary</h2>
        </div>

        {/* Primary Pattern Display */}
        <section className="mb-12">
          <div className="bg-surface-container-lowest rounded-[2rem] p-4 shadow-[0_24px_48px_-12px_rgba(7,30,39,0.08)] overflow-hidden">
            <div className="relative aspect-video rounded-[1.5rem] overflow-hidden bg-slate-900">
              <img alt="Abstract 3D geometric pattern" className="w-full h-full object-cover opacity-90" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB3QZan0FyKwtBPlgVnS7GUE9xM7723kOIhxq3Jo-SnGBxUxeTUOI-7dYrM0GptPUKqqitqrZXAOSUhx6GCQKU5I2_IKBPtBP7asRlPD60z5Y2Qerir_60N2Bn9Yw-wlh_AnSWDhTH7hZ0F8r9_F8sA8kFojo0joEVpw08fMUgTMW6dV8R3vzNBfSIcsE39pXBxa4dX26WW38KOZ75Bt6DUgz7QvTlynVRbxJPh8jchuh4wCklAH0u3-oXgsIWiD0BkpqQ-qpqXbKE" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none"></div>
            </div>
          </div>
        </section>

        {/* Pattern Characteristics & Metadata */}
        <section className="grid md:grid-cols-12 gap-12">
          <div className="md:col-span-7">
            <div className="space-y-6">
              <div>
                <h3 className="text-3xl font-bold tracking-tight text-on-surface mb-2">Geometric Matrix 14</h3>
                <div className="h-1 w-16 bg-primary rounded-full mb-6"></div>
              </div>
              <p className="text-on-surface-variant text-lg leading-relaxed font-medium">
                This pattern utilizes a 3D rotation rule around a central vertical axis, combined with a progressive grayscale shift in the lower quadrants.
              </p>

              <div className="bg-surface-container-low p-6 rounded-2xl space-y-4">
                <div className="flex items-start gap-4">
                  <Brain className="text-secondary w-6 h-6 mt-1 shrink-0" />
                  <div>
                    <p className="text-xs text-on-surface-variant font-bold uppercase tracking-wider mb-1">Observation Note</p>
                    <p className="text-sm text-on-surface">The central vertex acts as the anchor for all spatial transformations within this specific sequence.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-5">
            <div className="bg-surface-container p-8 rounded-[2rem] h-full">
              <h4 className="text-sm font-extrabold uppercase tracking-[0.2em] text-primary mb-6">Metadata Analysis</h4>
              <ul className="space-y-6">
                <li className="flex flex-col border-l-2 border-primary/20 pl-4 py-1">
                  <span className="text-[10px] uppercase font-bold text-on-surface-variant/70 tracking-widest">Category</span>
                  <span className="text-on-surface font-semibold text-lg">Logical Synthesis</span>
                </li>
                <li className="flex flex-col border-l-2 border-primary/20 pl-4 py-1">
                  <span className="text-[10px] uppercase font-bold text-on-surface-variant/70 tracking-widest">Complexity</span>
                  <span className="text-on-surface font-semibold text-lg">Tier 3</span>
                </li>
                <li className="flex flex-col border-l-2 border-primary/20 pl-4 py-1">
                  <span className="text-[10px] uppercase font-bold text-on-surface-variant/70 tracking-widest">Sequence</span>
                  <span className="text-on-surface font-semibold text-lg">3x3 Matrix</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* Additional Context Bento Style */}
        <section className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-surface-container-lowest p-8 rounded-[2rem] border border-outline-variant/10">
            <Lightbulb className="text-primary w-10 h-10 mb-4 fill-current" />
            <h5 className="text-xl font-bold mb-2">Key Heuristic</h5>
            <p className="text-on-surface-variant">Focus on the convergence of the lines rather than the shaded areas for faster rule identification.</p>
          </div>
          <div className="bg-secondary-container/30 p-8 rounded-[2rem] border border-secondary-container/50">
            <History className="text-secondary w-10 h-10 mb-4" />
            <h5 className="text-xl font-bold mb-2">Past Performance</h5>
            <p className="text-on-surface-variant">This tier of pattern usually correlates with high-level spatial reasoning scores in standardized assessments.</p>
          </div>
        </section>
      </main>

      {/* BottomNavBar Shell */}
      <nav className="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-4 pb-8 pt-4 bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl rounded-t-[1.5rem] shadow-[0_-4px_24px_rgba(7,30,39,0.06)]">
        {/* Mark Reviewed (Inactive state for the screen logic) */}
        <button className="flex flex-col items-center justify-center text-on-surface-variant dark:text-slate-400 px-6 py-2 hover:bg-surface-container-low dark:hover:bg-slate-800 active:scale-[0.98] transition-transform rounded-2xl">
          <CheckCircle className="w-6 h-6 mb-1" />
          <span className="text-xs font-semibold uppercase tracking-wider">Mark Reviewed</span>
        </button>

        {/* Resume Test (Active state for the screen logic) */}
        <button 
          onClick={() => navigate('/results')}
          className="flex flex-col items-center justify-center bg-secondary-container dark:bg-teal-900 text-on-secondary-container dark:text-teal-100 rounded-2xl px-8 py-3 active:scale-[0.98] transition-transform shadow-lg shadow-secondary/10"
        >
          <Play className="w-6 h-6 mb-1 fill-current" />
          <span className="text-xs font-semibold uppercase tracking-wider">Resume Test</span>
        </button>
      </nav>
    </div>
  );
}
